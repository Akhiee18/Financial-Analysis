import React from "react";
import Table from "../components/TransactionsTable";


export default function Transactions() {
 

    return(
        <Table />
    )
}