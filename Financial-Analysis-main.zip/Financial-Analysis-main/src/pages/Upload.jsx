import React from 'react'
import Uploadfile from '../components/Uploadfile'
const  Upload= () => {
  return (
    <Uploadfile/>
  )
}
export default Upload
